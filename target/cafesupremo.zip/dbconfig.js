module.exports= {
dbuser: '', 
dbpassword: '', 
connectString: '' ,
walletpwd: ''
}
